export function getImages(path) {

    return `https://image.tmdb.org/t/p/original${path}`


}