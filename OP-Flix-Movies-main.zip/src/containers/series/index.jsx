

function Series() {

    return (
        <div>
            <h1>Series</h1>
            <p>este é o Series</p>
        </div>)

}


export default Series
