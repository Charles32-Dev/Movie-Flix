import styled from "styled-components";


export const Container = styled.div`
padding: 50px 0;
margin: 4rem 0;
width: 100%;
`